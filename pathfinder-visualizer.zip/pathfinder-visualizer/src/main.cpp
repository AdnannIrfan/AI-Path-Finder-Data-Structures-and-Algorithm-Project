#include <SFML/Graphics.hpp>
#include <iostream>
#include "grid.h"
#include "algorithms.h"
#include "utils.h"

using namespace std;


struct QueueNode 
{
     int r, c; 
    };
class MyQueue 
{
    QueueNode *arr;
    int front, rear, size, capacity;
public:
    MyQueue(int cap)
     {
        capacity = cap;
        arr = new QueueNode[cap];
        front = size = 0;
        rear = cap - 1;
    }
    ~MyQueue()
     {
         delete[] arr; 
        }
    bool empty() 
    {
         return size == 0;
         }
    void push(int r, int c)
     {
        if (size == capacity) return;
        rear = (rear + 1) % capacity;
        arr[rear] = {r,c};
        size++;
    }
    QueueNode pop()
     {
        QueueNode item = arr[front];
        front = (front + 1) % capacity;
        size--;
        return item;
    }
};


struct StackNode 
{ 
    int r, c; 
};
class MyStack
 {
    StackNode *arr;
    int topIndex, capacity;
public:
    MyStack(int cap)
     {
        capacity = cap;
        arr = new StackNode[cap];
        topIndex = -1;
    }
    ~MyStack()
     {
         delete[] arr; 
        }
    bool empty() 
    { 
        return topIndex == -1; 
    }
    void push(int r,int c) 
    {
         if(topIndex+1<capacity) arr[++topIndex]={r,c};
         }
    StackNode pop() 
    {
         return arr[topIndex--]; 
        }
};

int main()
 {
    const int windowW = 900, windowH = 700;
    const int rows = 28, cols = 36;

    sf::RenderWindow window(sf::VideoMode(windowW, windowH), "Mini Google Maps - Pathfinding Visualizer");
    window.setFramerateLimit(60);

    Grid grid(rows, cols, windowW, windowH);

    int selectedAlg = 0;
    bool running = false;
    Algorithms::Result lastResult{false,0,0};

    sf::Font font;
    bool fontLoaded = font.loadFromFile("assets/Roboto-Regular.ttf");

    sf::Text titleText, infoText, statText;
    if(fontLoaded){
        titleText.setFont(font); titleText.setCharacterSize(18); titleText.setPosition(6,6); titleText.setFillColor(sf::Color::Black);
        titleText.setString("Mini Google Maps - Pathfinding Visualizer (Left-click: start/end/wall, Right-click: remove)");
        infoText.setFont(font); infoText.setCharacterSize(14); infoText.setFillColor(sf::Color::Black);
        statText.setFont(font); statText.setCharacterSize(14); statText.setFillColor(sf::Color::Black);
    }

    sf::RectangleShape overlayBg(sf::Vector2f(300,220));
    overlayBg.setPosition(580,10);
    overlayBg.setFillColor(sf::Color(230,230,230));
    overlayBg.setOutlineColor(sf::Color(180,180,180));
    overlayBg.setOutlineThickness(2.0f);

    while(window.isOpen()){
        sf::Event e;
        while(window.pollEvent(e))
        {
            if(e.type==sf::Event::Closed) window.close();
            else if(e.type==sf::Event::MouseButtonPressed && !running){
                int mx=e.mouseButton.x, my=e.mouseButton.y;
                bool left=(e.mouseButton.button==sf::Mouse::Left);
                bool right=(e.mouseButton.button==sf::Mouse::Right);
                grid.handleMousePress(mx,my,left,right);
            }
            else if(e.type==sf::Event::KeyPressed)
            {
                if(e.key.code==sf::Keyboard::Escape) window.close();
                if(e.key.code==sf::Keyboard::C) grid.resetGrid(true);
                if(e.key.code==sf::Keyboard::R) grid.resetGrid(false);

                if(e.key.code==sf::Keyboard::Space && !running)
                {
                    if(!grid.hasStart() || !grid.hasEnd()) cout<<"Please set both start and end positions.\n";
                    else
                    {
                        running=true;
                        if(selectedAlg==0) lastResult=Algorithms::runBFS(grid);
                        else if(selectedAlg==1) lastResult=Algorithms::runDFS(grid);
                        else if(selectedAlg==2) lastResult=Algorithms::runDijkstra(grid);
                        else if(selectedAlg==3) lastResult=Algorithms::runAStar(grid);
                        running=false;
                    }
                }

                if(e.key.code==sf::Keyboard::Right) selectedAlg=(selectedAlg+1)%4;
                if(e.key.code==sf::Keyboard::Left) selectedAlg=(selectedAlg-1+4)%4;

                if(e.key.code==sf::Keyboard::P){
                    if(!grid.hasStart() || !grid.hasEnd()){ cout<<"Set start and end first.\n"; }
                    else
                    {
                        grid.clearTraversal();
                        cout<<"Step-run of "<<algNameFromIndex(selectedAlg)<<" started...\n";

                        auto s=grid.getStart();
                        auto epos=grid.getEnd();
                        int sr=s.r, sc=s.c;
                        int er=epos.r, ec=epos.c;
                        bool found=false;

                        int nCount;
                        auto offs = Grid::neighborOffsets(nCount);

                        if(selectedAlg==0)
                        {
                            MyQueue q(rows*cols); q.push(sr,sc); grid.markVisited(sr,sc); grid.setPrev(sr,sc,-1,-1);
                            while(!q.empty())
                            {
                                auto cur=q.pop(); int r=cur.r, c=cur.c;
                                if(r==er && c==ec){ found=true; break;
                                 }
                                for(int i=0;i<4;i++)
                                {
                                    int nr=r+offs[i].r, nc=c+offs[i].c;
                                    if(!grid.inBounds(nr,nc) || grid.isWall(nr,nc) || grid.wasVisited(nr,nc)) continue;
                                    grid.markVisited(nr,nc); grid.setPrev(nr,nc,r,c); q.push(nr,nc);
                                }
                                window.clear(sf::Color::White); grid.draw(window); window.draw(overlayBg);
                                if(fontLoaded)
                                { infoText.setString("Algorithm: BFS (step-run)"); infoText.setPosition(windowW-300,20); window.draw(infoText);}
                                window.display();
                                sf::sleep(sf::milliseconds(25));
                            }
                        }
                        else if(selectedAlg==1)
                        {
                            MyStack st(rows*cols); st.push(sr,sc); grid.markVisited(sr,sc); grid.setPrev(sr,sc,-1,-1);
                            while(!st.empty())
                            {
                                auto cur=st.pop(); int r=cur.r, c=cur.c;
                                if(r==er && c==ec)
                                { 
                                    found=true; break;
                                 }
                                for(int i=3;i>=0;i--)
                                {
                                    int nr=r+offs[i].r, nc=c+offs[i].c;
                                    if(!grid.inBounds(nr,nc) || grid.isWall(nr,nc) || grid.wasVisited(nr,nc)) continue;
                                    grid.markVisited(nr,nc); grid.setPrev(nr,nc,r,c); st.push(nr,nc);
                                }
                                window.clear(sf::Color::White); grid.draw(window); window.draw(overlayBg);
                                if(fontLoaded){ infoText.setString("Algorithm: DFS (step-run)"); infoText.setPosition(windowW-300,20); window.draw(infoText);}
                                window.display();
                                sf::sleep(sf::milliseconds(25));
                            }
                        }
                        else
                        {
                            MyQueue q(rows*cols); q.push(sr,sc); grid.markVisited(sr,sc); grid.setPrev(sr,sc,-1,-1);
                            while(!q.empty())
                            {
                                auto cur=q.pop(); int r=cur.r, c=cur.c;
                                if(r==er && c==ec)
                                { 
                                    found=true; break; 
                                }
                                for(int i=0;i<4;i++)
                                {
                                    int nr=r+offs[i].r, nc=c+offs[i].c;
                                    if(!grid.inBounds(nr,nc) || grid.isWall(nr,nc) || grid.wasVisited(nr,nc)) continue;
                                    grid.markVisited(nr,nc); grid.setPrev(nr,nc,r,c); q.push(nr,nc);
                                }
                                window.clear(sf::Color::White); grid.draw(window); window.draw(overlayBg);
                                if(fontLoaded)
                                {
                                    string alg = selectedAlg==2?"Dijkstra (step-run)":"A* (step-run)";
                                    infoText.setString("Algorithm: "+alg); infoText.setPosition(windowW-300,20); window.draw(infoText);
                                }
                                window.display();
                                sf::sleep(sf::milliseconds(25));
                            }
                        }

                        if(found) Algorithms::backtrackPath(grid,er,ec);
                    }
                }
            }
        }

        window.clear(sf::Color::White); grid.draw(window);
        overlayBg.setPosition(windowW-310,10); window.draw(overlayBg);
        if(fontLoaded)
        {
            infoText.setPosition(windowW-300,20); statText.setPosition(windowW-300,50);
            infoText.setString("Algorithm: "+algNameFromIndex(selectedAlg));
            string status="Start: ";
            if(grid.hasStart())
            { 
                auto s=grid.getStart(); status+="("+to_string(s.r)+","+to_string(s.c)+")";
             } 
                else status+="Not set";
            status+="  End: ";
            if(grid.hasEnd())
            { auto e=grid.getEnd(); status+="("+to_string(e.r)+","+to_string(e.c)+")"; 
            } 
            else status+="Not set";
            statText.setString(status); window.draw(infoText); window.draw(statText);

            sf::Text help; help.setFont(font); help.setCharacterSize(12); help.setPosition(windowW-300,80);
            help.setFillColor(sf::Color::Black);
            help.setString("Keys:\n Left/Right: Change algorithm\n Space: Run\n P: Step-run (all algorithms)\n C: Clear traversal\n R: Reset all\n Left-Click: Start/End/Wall\n Right-Click: Remove");
            window.draw(help);

            sf::Text resText; resText.setFont(font); resText.setCharacterSize(12); resText.setPosition(windowW-300,200); resText.setFillColor(sf::Color::Black);
            if(lastResult.found)
            {
                resText.setString("Last result:\n Found\n Visited: "+to_string(lastResult.visitedCount)+"\n Path length: "+to_string(lastResult.pathLength));
            } 
            else resText.setString("Last result:\n Not found or not run");
            window.draw(resText);
        }

        window.display();
    }

    return 0;
}
