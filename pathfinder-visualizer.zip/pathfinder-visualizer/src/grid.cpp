#include "grid.h"

struct Grid::CellState
 {
    bool wall = false;
    bool visited = false;
    bool path = false;
    int prevR = -1;
    int prevC = -1;
};

static const Grid::Coord OFFSETS[4] = 
{
    {-1,0}, {1,0}, {0,-1}, {0,1}
};

const Grid::Coord* Grid::neighborOffsets(int &count)
 {
    count = 4;
    return OFFSETS;
}

Grid::Grid(int rows, int cols, int windowWidth, int windowHeight)
: m_rows(rows), m_cols(cols), m_windowW(windowWidth), m_windowH(windowHeight) 
{
    m_cellW = static_cast<float>(m_windowW) / m_cols;
    m_cellH = static_cast<float>(m_windowH) / m_rows;
    m_cells = new CellState[m_rows * m_cols];
    startR = startC = -1;
    endR = endC = -1;
}

void Grid::draw(sf::RenderWindow &window) 
{
    for (int r = 0; r < m_rows; ++r) 
    {
        for (int c = 0; c < m_cols; ++c) 
        {

            float x = c * m_cellW;
            float y = r * m_cellH;
            sf::RectangleShape rect(sf::Vector2f(m_cellW - 1.0f, m_cellH - 1.0f));
            rect.setPosition(x, y);

            CellState &cell = m_cells[r * m_cols + c];
            if (r == startR && c == startC) rect.setFillColor(sf::Color(0,180,0));
            else if
             (r == endR && c == endC) rect.setFillColor(sf::Color(200,0,0));
            else if
             (cell.wall) rect.setFillColor(sf::Color(20,20,20));
            else if
             (cell.path) rect.setFillColor(sf::Color(50,120,255));
            else if
             (cell.visited) rect.setFillColor(sf::Color(240,220,80));
            else
             rect.setFillColor(sf::Color(240,240,240));

            window.draw(rect);
        }
    }

    for (int r = 0; r <= m_rows; ++r) 
    {
        sf::Vertex line[] = 
        {
            sf::Vertex(sf::Vector2f(0, r*m_cellH), sf::Color(200,200,200)),
            sf::Vertex(sf::Vector2f((float)m_windowW, r*m_cellH), sf::Color(200,200,200))
        };
        window.draw(line, 2, sf::Lines);
    }
    for (int c = 0; c <= m_cols; ++c) 
    {
        sf::Vertex line[] = 
        {
            sf::Vertex(sf::Vector2f(c*m_cellW, 0), sf::Color(200,200,200)),
            sf::Vertex(sf::Vector2f(c*m_cellW, (float)m_windowH), sf::Color(200,200,200))
        };
        window.draw(line, 2, sf::Lines);
    }
}

void Grid::handleMousePress(int mouseX, int mouseY, bool left, bool right) 
{
    int c = mouseX / static_cast<int>(m_cellW);
    int r = mouseY / static_cast<int>(m_cellH);
    if (!inBounds(r,c)) return;

    CellState &cell = m_cells[r * m_cols + c];

    if (left && !right)
     {
        if (startR == -1 && startC == -1) startR=startC=r=c;
        else if 
        (endR == -1 && endC == -1 && !(r==startR && c==startC)) endR=endC=r=c;
        else if
         (!(r==startR && c==startC) && !(r==endR && c==endC)) cell.wall=!cell.wall;
    } else if
     (right && !left) {
        if (r==startR && c==startC) startR=startC=-1;
        else if
         (r==endR && c==endC) endR=endC=-1;
        else 
        cell.wall=false;
    }
}

void Grid::resetGrid(bool keepStartEnd)
 {
    for (int i=0;i<m_rows*m_cols;i++)
     {
        m_cells[i].wall=false;
        m_cells[i].visited=false;
        m_cells[i].path=false;
        m_cells[i].prevR=-1;
        m_cells[i].prevC=-1;
    }
    if(!keepStartEnd) startR=startC=endR=endC=-1;
}

void Grid::clearTraversal()
 {
    for (int i=0;i<m_rows*m_cols;i++)
    {
        m_cells[i].visited=false;
        m_cells[i].path=false;
        m_cells[i].prevR=-1;
        m_cells[i].prevC=-1;
    }
}


Grid::Coord Grid::getStart() 
const 
{
     return {startR, startC}; 
    }
Grid::Coord Grid::getEnd()  
 const
  { 
    return {
        endR, endC
    }; 
}
bool Grid::hasStart()       
const {
     return startR != -1;
     }
bool Grid::hasEnd()         
const {
     return endR != -1; 
    }

void Grid::markVisited(int r, int c) 
{
    if (!inBounds(r,c)) return;
    m_cells[r*m_cols + c].visited = true;
}

void Grid::markPath(int r, int c) 
{
    if (!inBounds(r,c)) return;
    m_cells[r*m_cols + c].path = true;
}

void Grid::setWall(int r, int c, bool val) 
{
    if (!inBounds(r,c)) return;
    m_cells[r*m_cols + c].wall = val;
}

bool Grid::isWall(int r, int c) 
const {
    if (!inBounds(r,c)) return true;
    return m_cells[r*m_cols + c].wall;
}

sf::FloatRect Grid::cellRect(int r, int c) 
const {
    return sf::FloatRect(c*m_cellW, r*m_cellH, m_cellW, m_cellH);
}

bool Grid::inBounds(int r, int c) 
const {
    return r>=0 && r<m_rows && c>=0 && c<m_cols;
}

bool Grid::wasVisited(int r, int c) 
const {
    if(!inBounds(r,c)) return false;
    return m_cells[r*m_cols+c].visited;
}

bool Grid::isPath(int r, int c) 
const {
    if(!inBounds(r,c)) return false;
    return m_cells[r*m_cols+c].path;
}

void Grid::setPrev(int r, int c, int pr, int pc)
 {
    if(!inBounds(r,c)) return;
    m_cells[r*m_cols+c].prevR=pr;
    m_cells[r*m_cols+c].prevC=pc;
}

Grid::Coord Grid::getPrev(int r, int c)
 const {
    if(!inBounds(r,c)) return {-1,-1};
    const CellState &cell = m_cells[r*m_cols+c];
    return {cell.prevR, cell.prevC};
}
