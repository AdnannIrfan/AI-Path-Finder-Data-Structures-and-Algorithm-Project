#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>

class Grid; 

namespace Algorithms 
{
    
    struct Result
     {
        bool found;
        int visitedCount;
        int pathLength;
    };

    
    Result runBFS(Grid &grid);

    
    Result runDFS(Grid &grid);

    
    Result runDijkstra(Grid &grid);

   
    Result runAStar(Grid &grid);


    int backtrackPath(Grid &grid, int endR, int endC);
}
