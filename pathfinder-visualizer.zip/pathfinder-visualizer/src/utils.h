#ifndef UTILS_H
#define UTILS_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>

using namespace std; 

namespace Utils {
    
    inline sf::Vector2f gridToPixel(int row, int col, int cellSize) {
        return sf::Vector2f(col * cellSize, row * cellSize);
    }

  
    inline void log(const string& msg) {
        cout << "[LOG] " << msg << endl;
    }

    
    inline sf::Color visitedColor() {
        return sf::Color(255, 255, 0); 
    }

    
    inline sf::Color pathColor() {
        return sf::Color(0, 0, 255);
    }
}


inline string algNameFromIndex(int idx)
 {
    switch (idx) 
    {
        case 0: return "BFS";
        case 1: return "DFS";
        case 2: return "Dijkstra";
        case 3: return "A*";
        default: return "Unknown";
   
    }
}

#endif
