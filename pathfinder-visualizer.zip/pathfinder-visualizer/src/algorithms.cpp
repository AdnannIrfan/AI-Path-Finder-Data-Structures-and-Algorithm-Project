#include "algorithms.h"
#include "grid.h"
#include <iostream>

using namespace std;
using namespace Algorithms;

struct QueueNode
 {
    int r, c;
};

class MyQueue 
{
    QueueNode *arr;
    int front, rear, size, capacity;
public:
    MyQueue(int cap) 
    {
        capacity = cap;
        arr = new QueueNode[cap];
        front = size = 0;
        rear = cap - 1;
    }
    ~MyQueue()
     {
         delete[] arr; 
        }
    bool empty() { return size == 0;
     }
    void push(int r, int c)
     {
        if (size == capacity) return;
        rear = (rear + 1) % capacity;
        arr[rear] = {r,c};
        size++;
    }
    QueueNode pop() 
    {
        QueueNode item = arr[front];
        front = (front + 1) % capacity;
        size--;
        return item;
    }
};


struct StackNode
 {
    int r, c;
};
class MyStack 
{

    StackNode *arr;
    int topIndex, capacity;
public:
    MyStack(int cap) 
    {
        capacity = cap;
        arr = new StackNode[cap];
        topIndex = -1;
    }
    ~MyStack() { delete[] arr;
     }
    bool empty() {
         return topIndex == -1;
         }
    void push(int r,int c)
     {
        if (topIndex+1 < capacity) arr[++topIndex] = {r,c};
    }
    StackNode pop() 
    {
        return arr[topIndex--];
    }
};


struct HeapNode 
{
    int cost;
    int r, c;
};
class MinHeap
 {
    HeapNode *arr;
    int size, capacity;
    void heapifyUp(int i) {
        while (i>0 && arr[(i-1)/2].cost > arr[i].cost)
         {
            HeapNode t = arr[i]; arr[i] = arr[(i-1)/2]; arr[(i-1)/2] = t;
            i = (i-1)/2;
        }
    }
    void heapifyDown(int i) 
    {
        int smallest = i;
        int l = 2*i+1, r = 2*i+2;
        if (l<size && arr[l].cost < arr[smallest].cost) smallest = l;
        if (r<size && arr[r].cost < arr[smallest].cost) smallest = r;
        if (smallest!=i) {
            HeapNode t=arr[i]; arr[i]=arr[smallest]; arr[smallest]=t;
            heapifyDown(smallest);
        }
    }
public:
    MinHeap(int cap)
    { 
        capacity=cap; arr=new HeapNode[cap]; size=0;
     }
    ~MinHeap(){
         delete[] arr; 
        }
    bool empty()
    {
         return size==0; 
        }
    void push(int cost,int r,int c)
    {
        if (size==capacity) return;
        arr[size]={cost,r,c};
        heapifyUp(size);
        size++;
    }
    HeapNode pop()
    {
        HeapNode root=arr[0];
        arr[0]=arr[size-1];
        size--;
        heapifyDown(0);
        return root;
    }
};


Result Algorithms::runBFS(Grid &grid) 
{
    Result res{false,0,0};
    if (!grid.hasStart() || !grid.hasEnd()) return res;

    grid.clearTraversal();
    auto s = grid.getStart();
    auto e = grid.getEnd();
    int sr = s.r, sc = s.c, er = e.r, ec = e.c;

    MyQueue q(grid.rows()*grid.cols());
    q.push(sr,sc);
    grid.markVisited(sr,sc);
    grid.setPrev(sr,sc,-1,-1);

    int visited=0; bool found=false;
    int count; auto offs = Grid::neighborOffsets(count);
    while(!q.empty()) 
    {
        auto cur = q.pop(); visited++;
        int r = cur.r, c = cur.c;
        if(r==er && c==ec){ found=true; break;
         }

        for(int i=0;i<count;i++)
        {
            int nr=r+offs[i].r, nc=c+offs[i].c;
            if(!grid.inBounds(nr,nc) || grid.isWall(nr,nc) || grid.wasVisited(nr,nc)) continue;
            grid.markVisited(nr,nc);
            grid.setPrev(nr,nc,r,c);
            q.push(nr,nc);
        }

    }
    if(found) res={true,visited,backtrackPath(grid,er,ec)};
    else res={false,visited,0};
    return res;
}


Result Algorithms::runDFS(Grid &grid)
 {
    Result res{false,0,0};
    if(!grid.hasStart()||!grid.hasEnd()) return res;

    grid.clearTraversal();
    auto s = grid.getStart();
    auto e = grid.getEnd();
    int sr = s.r, sc = s.c, er = e.r, ec = e.c;

    MyStack st(grid.rows()*grid.cols());
    st.push(sr,sc);
    grid.markVisited(sr,sc);
    grid.setPrev(sr,sc,-1,-1);

    int visited=0; bool found=false;
    int count; auto offs = Grid::neighborOffsets(count);
    while(!st.empty())
    {
        auto cur=st.pop(); visited++;
        int r = cur.r, c = cur.c;
        if(r==er && c==ec){ found=true; break; 
        }

        for(int i=count-1;i>=0;i--)
        {
            int nr=r+offs[i].r, nc=c+offs[i].c;
            if(!grid.inBounds(nr,nc) || grid.isWall(nr,nc) || grid.wasVisited(nr,nc)) continue;
            grid.markVisited(nr,nc);
            grid.setPrev(nr,nc,r,c);
            st.push(nr,nc);
        }

    }
    if(found) res={true,visited,backtrackPath(grid,er,ec)
    };
    else 
    res={false,visited,0};
    return res;
}


Result Algorithms::runDijkstra(Grid &grid) 
{
    Result res{false,0,0};
    if(!grid.hasStart()||!grid.hasEnd()) return res;

    grid.clearTraversal();
    auto s = grid.getStart();
    auto e = grid.getEnd();
    int sr = s.r, sc = s.c, er = e.r, ec = e.c;

    int R=grid.rows(), C=grid.cols();
    int N=R*C, INF=1e9;
    int *dist=new int[N];
    for(int i=0;i<N;i++) dist[i]=INF;

    auto idx=[&](int r,int c){
        return r*C+c;
    };

    MinHeap pq(N);
    dist[idx(sr,sc)]=0;
    pq.push(0,sr,sc);
    grid.setPrev(sr,sc,-1,-1);

    int visited=0; bool found=false;
    int count; auto offs = Grid::neighborOffsets(count);
    while(!pq.empty())
    {
        auto top = pq.pop();
        int d = top.cost, r = top.r, c = top.c;
        if(d != dist[idx(r,c)]) continue;
        if(grid.isWall(r,c)) continue;
        if(!grid.wasVisited(r,c))
        {
             grid.markVisited(r,c); visited++; 
        }
        if(r==er && c==ec)
        { 
            found=true; break; 
        }

        for(int i=0;i<count;i++)
        {
            int nr=r+offs[i].r, nc=c+offs[i].c;
            if(!grid.inBounds(nr,nc) || grid.isWall(nr,nc)) continue;
            int nd = d+1;
            if(nd < dist[idx(nr,nc)])
            {
                dist[idx(nr,nc)] = nd;
                grid.setPrev(nr,nc,r,c);
                pq.push(nd,nr,nc);
            }
        }
    }
    delete[] dist;
    if(found) res=
    {
        true,visited,backtrackPath(grid,er,ec)
    };
    else 
    res={false,visited,0};
    return res;
}


static int manhattan(int r1,int c1,int r2,int c2)
{
    int dr=r1-r2; if(dr<0) dr=-dr;
    int dc=c1-c2; if(dc<0) dc=-dc;
    return dr+dc;
}


Result Algorithms::runAStar(Grid &grid)
{
    Result res{false,0,0};
    if(!grid.hasStart()||!grid.hasEnd()) return res;

    grid.clearTraversal();
    auto s = grid.getStart();
    auto e = grid.getEnd();
    int sr = s.r, sc = s.c, er = e.r, ec = e.c;

    int R=grid.rows(), C=grid.cols();
    int N=R*C, INF=1e9;
    int *gscore=new int[N], *fscore=new int[N];
    bool *inOpen=new bool[N];
    for(int i=0;i<N;i++)
    { 
        gscore[i]=INF; fscore[i]=INF; inOpen[i]=false;
     }

    auto idx=[&](int r,int c)
    {
        return r*C+c;
    };

    MinHeap openSet(N);
    gscore[idx(sr,sc)] = 0;
    fscore[idx(sr,sc)] = manhattan(sr,sc,er,ec);
    openSet.push(fscore[idx(sr,sc)],sr,sc);
    inOpen[idx(sr,sc)] = true;
    grid.setPrev(sr,sc,-1,-1);

    int visited=0; bool found=false;
    int count; auto offs = Grid::neighborOffsets(count);
    while(!openSet.empty()){
        auto top = openSet.pop();
        int r = top.r, c = top.c;
        if(r==er && c==ec)
        {
             found=true; break;
             }
        if(!grid.wasVisited(r,c))
        { 
            grid.markVisited(r,c); visited++;
         }

        for(int i=0;i<count;i++)
        {
            int nr = r+offs[i].r, nc = c+offs[i].c;
            if(!grid.inBounds(nr,nc) || grid.isWall(nr,nc)) continue;
            int tentative = gscore[idx(r,c)] + 1;
            if(tentative < gscore[idx(nr,nc)])
            {
                gscore[idx(nr,nc)] = tentative;
                fscore[idx(nr,nc)] = tentative + manhattan(nr,nc,er,ec);
                grid.setPrev(nr,nc,r,c);
                if(!inOpen[idx(nr,nc)])
                {
                    openSet.push(fscore[idx(nr,nc)],nr,nc);
                    inOpen[idx(nr,nc)] = true;
                }
            }
        }
    }

    delete[] gscore; delete[] fscore; delete[] inOpen;
    if(found) res=
    {
        true,visited,backtrackPath(grid,er,ec)
    };
    else 
    res=
    {
        false,visited,0
    };
    return res;
}


int Algorithms::backtrackPath(Grid &grid,int endR,int endC)
{
    int cnt=0, r=endR, c=endC;
    while(true)
    {
        auto pr = grid.getPrev(r,c);
        grid.markPath(r,c);
        cnt++;
        if(pr.r==-1) break;
        r = pr.r; c = pr.c;
    }
    return (cnt>0?cnt-1:0);
}
