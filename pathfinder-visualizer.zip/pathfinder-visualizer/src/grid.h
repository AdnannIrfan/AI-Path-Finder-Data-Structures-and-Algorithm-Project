#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>

using namespace std;

class Grid 
{
public:
    struct Coord 
    {
        int r;
        int c;
    };

    Grid(int rows, int cols, int windowWidth, int windowHeight);

    void draw(sf::RenderWindow &window);
    void handleMousePress(int mouseX, int mouseY, bool left, bool right);
    void resetGrid(bool keepStartEnd = true);
    void clearTraversal();

    
    Coord getStart() const;
    Coord getEnd() const;
    bool hasStart() const;
    bool hasEnd() const;

    void markVisited(int r, int c);
    void markPath(int r, int c);
    void setWall(int r, int c, bool val);
    bool isWall(int r, int c) const;

    sf::FloatRect cellRect(int r, int c) const;
    int rows() const
     {
         return m_rows;
         }
    int cols() const 
    { 
        return m_cols; 
    }
    bool inBounds(int r, int c) const;

    static const Coord* neighborOffsets(int &count);

    bool wasVisited(int r, int c) const;
    bool isPath(int r, int c) const;

    void setPrev(int r, int c, int pr, int pc);
    Coord getPrev(int r, int c) const;

private:
    int m_rows, m_cols;
    int m_windowW, m_windowH;
    float m_cellW, m_cellH;

    struct CellState;
    CellState* m_cells;

    int startR, startC;
    int endR, endC;
};
